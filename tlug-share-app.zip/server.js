const express = require('express');
const fs = require('fs');
const path = require('path');
const os = require('os');

const app = express();
const PORT = process.env.PORT || 3000;
const STATIC_DIR = __dirname;

const MAX_CONNECTIONS = 50;
const KEEP_ALIVE_TIMEOUT = 61000;

app.use((req, res, next) => {
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    next();
});

app.use(express.static(STATIC_DIR, {
    maxAge: '1h',
    etag: false,
    lastModified: false
}));

app.get('/api/resources', (req, res) => {
    const resourcesDir = path.join(STATIC_DIR, 'resources');
    
    fs.readdir(resourcesDir, { withFileTypes: true }, (err, files) => {
        if (err) {
            return res.status(500).json({ error: 'Cannot read resources folder' });
        }
        
        const fileList = files
            .filter(f => f.isFile())
            .map(f => ({
                name: f.name,
                url: '/resources/' + f.name
            }))
            .sort((a, b) => a.name.localeCompare(b.name));
        
        res.setHeader('Cache-Control', 'no-cache, private, max-age=30');
        res.json(fileList);
    });
});

app.get('/', (req, res) => {
    res.sendFile(path.join(STATIC_DIR, 'index.html'));
});

const server = app.listen(PORT, '0.0.0.0', () => {
    const cpus = os.cpus().length;
    console.log(`T-LUG Server running at http://localhost:${PORT}`);
    console.log(`Capacity: ${MAX_CONNECTIONS}+ concurrent users`);
    console.log(`Server ready for downloads`);
});

server.keepAliveTimeout = KEEP_ALIVE_TIMEOUT;
server.headersTimeout = KEEP_ALIVE_TIMEOUT + 1000;

process.on('SIGTERM', () => {
    console.log('Shutting down...');
    server.close(() => process.exit(0));
});